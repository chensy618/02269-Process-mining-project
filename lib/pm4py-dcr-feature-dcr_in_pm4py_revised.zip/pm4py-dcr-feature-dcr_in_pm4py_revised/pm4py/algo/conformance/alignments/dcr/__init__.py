from pm4py.algo.conformance.alignments.dcr import variants, algorithm

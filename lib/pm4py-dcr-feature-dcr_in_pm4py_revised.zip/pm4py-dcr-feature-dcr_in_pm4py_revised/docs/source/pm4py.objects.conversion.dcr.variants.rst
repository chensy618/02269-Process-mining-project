pm4py.objects.conversion.dcr.variants package
=============================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pm4py.objects.conversion.dcr.variants.to_petri_net_submodules
   pm4py.objects.conversion.dcr.variants.to_timed_arc_petri_net_submodules

Submodules
----------

pm4py.objects.conversion.dcr.variants.reachability\_analysis module
-------------------------------------------------------------------

.. automodule:: pm4py.objects.conversion.dcr.variants.reachability_analysis
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.objects.conversion.dcr.variants.to\_inhibitor\_net module
---------------------------------------------------------------

.. automodule:: pm4py.objects.conversion.dcr.variants.to_inhibitor_net
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.objects.conversion.dcr.variants.to\_timed\_arc\_petri\_net module
-----------------------------------------------------------------------

.. automodule:: pm4py.objects.conversion.dcr.variants.to_timed_arc_petri_net
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.objects.conversion.dcr.variants
   :members:
   :undoc-members:
   :show-inheritance:

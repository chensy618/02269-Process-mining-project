pm4py.algo.discovery package
============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pm4py.algo.discovery.dcr_discover

Module contents
---------------

.. automodule:: pm4py.algo.discovery
   :members:
   :undoc-members:
   :show-inheritance:

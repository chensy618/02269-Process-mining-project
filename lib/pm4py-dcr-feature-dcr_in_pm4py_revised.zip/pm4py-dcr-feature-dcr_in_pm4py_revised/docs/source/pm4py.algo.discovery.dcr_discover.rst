pm4py.algo.discovery.dcr\_discover package
==========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pm4py.algo.discovery.dcr_discover.extenstions
   pm4py.algo.discovery.dcr_discover.variants

Submodules
----------

pm4py.algo.discovery.dcr\_discover.algorithm module
---------------------------------------------------

.. automodule:: pm4py.algo.discovery.dcr_discover.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.algo.discovery.dcr_discover
   :members:
   :undoc-members:
   :show-inheritance:

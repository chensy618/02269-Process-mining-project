pm4py.objects.dcr.importer.variants package
===========================================

Submodules
----------

pm4py.objects.dcr.importer.variants.xml\_dcr\_portal module
-----------------------------------------------------------

.. automodule:: pm4py.objects.dcr.importer.variants.xml_dcr_portal
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.objects.dcr.importer.variants.xml\_simple module
------------------------------------------------------

.. automodule:: pm4py.objects.dcr.importer.variants.xml_simple
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.objects.dcr.importer.variants
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.algo.conformance.dcr.variants package
===========================================

Submodules
----------

pm4py.algo.conformance.dcr.variants.classic module
--------------------------------------------------

.. automodule:: pm4py.algo.conformance.dcr.variants.classic
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.algo.conformance.dcr.variants
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.algo.conformance package
==============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pm4py.algo.conformance.alignments
   pm4py.algo.conformance.dcr

Module contents
---------------

.. automodule:: pm4py.algo.conformance
   :members:
   :undoc-members:
   :show-inheritance:

tests package
=============

Submodules
----------

tests.algorithm\_test module
----------------------------

.. automodule:: tests.algorithm_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.alignment\_test module
----------------------------

.. automodule:: tests.alignment_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.alpha\_test module
------------------------

.. automodule:: tests.alpha_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.bpmn\_tests module
------------------------

.. automodule:: tests.bpmn_tests
   :members:
   :undoc-members:
   :show-inheritance:

tests.constants module
----------------------

.. automodule:: tests.constants
   :members:
   :undoc-members:
   :show-inheritance:

tests.csv\_impexp\_test module
------------------------------

.. automodule:: tests.csv_impexp_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.dcr\_test module
----------------------

.. automodule:: tests.dcr_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.dec\_tree\_test module
----------------------------

.. automodule:: tests.dec_tree_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.dfg\_tests module
-----------------------

.. automodule:: tests.dfg_tests
   :members:
   :undoc-members:
   :show-inheritance:

tests.diagn\_df\_conf\_checking module
--------------------------------------

.. automodule:: tests.diagn_df_conf_checking
   :members:
   :undoc-members:
   :show-inheritance:

tests.doc\_tests module
-----------------------

.. automodule:: tests.doc_tests
   :members:
   :undoc-members:
   :show-inheritance:

tests.etc\_tests module
-----------------------

.. automodule:: tests.etc_tests
   :members:
   :undoc-members:
   :show-inheritance:

tests.evaluation\_tests module
------------------------------

.. automodule:: tests.evaluation_tests
   :members:
   :undoc-members:
   :show-inheritance:

tests.execute\_tests module
---------------------------

.. automodule:: tests.execute_tests
   :members:
   :undoc-members:
   :show-inheritance:

tests.filtering\_log\_test module
---------------------------------

.. automodule:: tests.filtering_log_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.filtering\_pandas\_test module
------------------------------------

.. automodule:: tests.filtering_pandas_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.graphs\_forming module
----------------------------

.. automodule:: tests.graphs_forming
   :members:
   :undoc-members:
   :show-inheritance:

tests.heuminer\_test module
---------------------------

.. automodule:: tests.heuminer_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.imp\_everything module
----------------------------

.. automodule:: tests.imp_everything
   :members:
   :undoc-members:
   :show-inheritance:

tests.imp\_exp\_from\_string module
-----------------------------------

.. automodule:: tests.imp_exp_from_string
   :members:
   :undoc-members:
   :show-inheritance:

tests.inductive\_test module
----------------------------

.. automodule:: tests.inductive_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.inductive\_tree\_test module
----------------------------------

.. automodule:: tests.inductive_tree_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.llm\_test module
----------------------

.. automodule:: tests.llm_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.main\_fac\_test module
----------------------------

.. automodule:: tests.main_fac_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.ocel\_discovery\_test module
----------------------------------

.. automodule:: tests.ocel_discovery_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.ocel\_filtering\_test module
----------------------------------

.. automodule:: tests.ocel_filtering_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.other\_tests module
-------------------------

.. automodule:: tests.other_tests
   :members:
   :undoc-members:
   :show-inheritance:

tests.passed\_time module
-------------------------

.. automodule:: tests.passed_time
   :members:
   :undoc-members:
   :show-inheritance:

tests.petri\_imp\_exp\_test module
----------------------------------

.. automodule:: tests.petri_imp_exp_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.role\_detection module
----------------------------

.. automodule:: tests.role_detection
   :members:
   :undoc-members:
   :show-inheritance:

tests.simplified\_interface module
----------------------------------

.. automodule:: tests.simplified_interface
   :members:
   :undoc-members:
   :show-inheritance:

tests.simplified\_interface\_2 module
-------------------------------------

.. automodule:: tests.simplified_interface_2
   :members:
   :undoc-members:
   :show-inheritance:

tests.simulation\_test module
-----------------------------

.. automodule:: tests.simulation_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.sna\_test module
----------------------

.. automodule:: tests.sna_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.statistics\_df\_test module
---------------------------------

.. automodule:: tests.statistics_df_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.statistics\_log\_test module
----------------------------------

.. automodule:: tests.statistics_log_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_cli module
----------------------

.. automodule:: tests.test_cli
   :members:
   :undoc-members:
   :show-inheritance:

tests.trans\_syst\_tests module
-------------------------------

.. automodule:: tests.trans_syst_tests
   :members:
   :undoc-members:
   :show-inheritance:

tests.woflan\_tests module
--------------------------

.. automodule:: tests.woflan_tests
   :members:
   :undoc-members:
   :show-inheritance:

tests.xes\_impexp\_test module
------------------------------

.. automodule:: tests.xes_impexp_test
   :members:
   :undoc-members:
   :show-inheritance:

tests.xescerttest module
------------------------

.. automodule:: tests.xescerttest
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tests
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.algo.conformance.alignments.dcr package
=============================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pm4py.algo.conformance.alignments.dcr.variants

Submodules
----------

pm4py.algo.conformance.alignments.dcr.algorithm module
------------------------------------------------------

.. automodule:: pm4py.algo.conformance.alignments.dcr.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.algo.conformance.alignments.dcr
   :members:
   :undoc-members:
   :show-inheritance:

Documentation
===================================
We used the pm4py's format to create the documentation

``DCR4Py`` is an extension of ``pm4py`` a open-source Python library to allow support for DCR Graph.

Contents
--------

.. toctree::
   :maxdepth: 2

   api

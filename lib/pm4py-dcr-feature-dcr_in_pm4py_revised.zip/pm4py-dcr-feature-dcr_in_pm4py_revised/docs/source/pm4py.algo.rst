pm4py.algo package
==================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pm4py.algo.conformance
   pm4py.algo.discovery

Module contents
---------------

.. automodule:: pm4py.algo
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.algo.conformance.alignments package
=========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pm4py.algo.conformance.alignments.dcr

Module contents
---------------

.. automodule:: pm4py.algo.conformance.alignments
   :members:
   :undoc-members:
   :show-inheritance:

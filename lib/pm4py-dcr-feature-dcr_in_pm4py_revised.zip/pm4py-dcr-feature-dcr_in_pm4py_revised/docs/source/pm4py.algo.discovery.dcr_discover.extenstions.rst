pm4py.algo.discovery.dcr\_discover.extenstions package
======================================================

Submodules
----------

pm4py.algo.discovery.dcr\_discover.extenstions.nesting module
-------------------------------------------------------------

.. automodule:: pm4py.algo.discovery.dcr_discover.extenstions.nesting
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.algo.discovery.dcr\_discover.extenstions.pending module
-------------------------------------------------------------

.. automodule:: pm4py.algo.discovery.dcr_discover.extenstions.pending
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.algo.discovery.dcr\_discover.extenstions.roles module
-----------------------------------------------------------

.. automodule:: pm4py.algo.discovery.dcr_discover.extenstions.roles
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.algo.discovery.dcr\_discover.extenstions.time\_constraints module
-----------------------------------------------------------------------

.. automodule:: pm4py.algo.discovery.dcr_discover.extenstions.time_constraints
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.algo.discovery.dcr_discover.extenstions
   :members:
   :undoc-members:
   :show-inheritance:

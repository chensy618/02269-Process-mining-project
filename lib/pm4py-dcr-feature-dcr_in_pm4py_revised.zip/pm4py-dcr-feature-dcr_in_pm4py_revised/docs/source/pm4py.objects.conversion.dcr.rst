pm4py.objects.conversion.dcr package
====================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pm4py.objects.conversion.dcr.variants

Submodules
----------

pm4py.objects.conversion.dcr.converter module
---------------------------------------------

.. automodule:: pm4py.objects.conversion.dcr.converter
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.objects.conversion.dcr
   :members:
   :undoc-members:
   :show-inheritance:

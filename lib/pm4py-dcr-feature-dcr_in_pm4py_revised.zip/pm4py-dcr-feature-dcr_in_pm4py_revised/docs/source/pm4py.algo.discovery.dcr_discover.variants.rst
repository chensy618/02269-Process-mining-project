pm4py.algo.discovery.dcr\_discover.variants package
===================================================

Submodules
----------

pm4py.algo.discovery.dcr\_discover.variants.dcr\_discover module
----------------------------------------------------------------

.. automodule:: pm4py.algo.discovery.dcr_discover.variants.dcr_discover
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.algo.discovery.dcr_discover.variants
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.algo.conformance.dcr package
==================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pm4py.algo.conformance.dcr.decorators
   pm4py.algo.conformance.dcr.rules
   pm4py.algo.conformance.dcr.variants

Submodules
----------

pm4py.algo.conformance.dcr.algorithm module
-------------------------------------------

.. automodule:: pm4py.algo.conformance.dcr.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.algo.conformance.dcr
   :members:
   :undoc-members:
   :show-inheritance:

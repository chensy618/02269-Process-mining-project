pm4py.algo.conformance.dcr.decorators package
=============================================

Submodules
----------

pm4py.algo.conformance.dcr.decorators.decorator module
------------------------------------------------------

.. automodule:: pm4py.algo.conformance.dcr.decorators.decorator
   :members:
   :undoc-members:
   :show-inheritance:

pm4py.algo.conformance.dcr.decorators.roledecorator module
----------------------------------------------------------

.. automodule:: pm4py.algo.conformance.dcr.decorators.roledecorator
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pm4py.algo.conformance.dcr.decorators
   :members:
   :undoc-members:
   :show-inheritance:

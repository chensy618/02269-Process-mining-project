Examples
============

Filtering XYZ
-------------

Decision Point Analysis
-----------------------

Computing a DFG with Performance Overlay
----------------------------------------